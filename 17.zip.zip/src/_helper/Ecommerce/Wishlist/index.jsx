import { createContext } from 'react';

const WishtListContext = createContext();

export default WishtListContext;
