import { createContext } from 'react';

const GalleryContext = createContext();

export default GalleryContext;
