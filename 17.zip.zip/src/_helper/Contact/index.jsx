import { createContext } from 'react';

const ContactAppContext = createContext();

export default ContactAppContext;
