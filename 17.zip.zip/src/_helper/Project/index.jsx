import { createContext } from 'react';

const ProjectContext = createContext();

export default ProjectContext;
