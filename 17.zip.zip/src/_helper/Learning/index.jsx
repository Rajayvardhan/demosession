import { createContext } from 'react';

const LearningContext = createContext();

export default LearningContext;
