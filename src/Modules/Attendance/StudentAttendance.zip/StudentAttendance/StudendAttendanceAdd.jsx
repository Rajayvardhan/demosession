import React from 'react'

export default function StudendAttendanceAdd() {
  return (
    <div>StudendAttendanceAdd</div>
  )
}
