import axios from 'axios';
import React, { useState } from 'react';
import { BaseURL } from '../../../api/DataApis';
import request from '../../../Apis/request';

const Add = () => {
  const [selectedOption2, setSelectedOption2] = useState('');
  const [selectedOption3, setSelectedOption3] = useState('');
  const [selectedOption4, setSelectedOption4] = useState('');
  const [listItems, setListItems] = useState([]);

  const handleOption2Change = (event) => {
    setSelectedOption2(event.target.value);
  };

  const handleOption3Change = (event) => {
    setSelectedOption3(event.target.value);
  };

  const handleOption4Change = (event) => {
    setSelectedOption4(event.target.value);
  };

  const apiEndpoint = `${BaseURL}/classes/getClasses`;
  const fetchData = async () => {
    try {
      const response = await request({
        url: apiEndpoint,
        method: "GET",
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
        }
      });
      if (response && response.classes) {
        const students = response.classes; // Assuming classes contain an array of students
        const items = students.map((student, index) => (
          <tr key={index}>
            <td>{index + 1}</td>
            <td></td> {/* Add student photo here */}
            <td>{student.name}</td>
            {/* <td>{student.email}</td> */}
            <td>{student.roll}</td>
            <td>
              <input
                type="checkbox"
                onChange={(event) => handleCheckboxChange(event, student.id)}
              />
            </td>
          </tr>
        ));
        setListItems(items);
      }
    } catch (error) {
      console.error("Error fetching student data:", error);
    }
  };

  const handleCheckboxChange = async (event, studentId) => {
    const isChecked = event.target.checked;
    if (isChecked) {
      try {
        const response = await axios.post(
          "https://demo.keendroid.in/sattendance/singleAdd",
          {
            id: studentId,
            day: "12"
          }
        );
        const { data } = response;
        console.log(data);
        alert("success attendance")
      } catch (error) {
        console.error("Error:", error);
      }
    }
  };

  return (
    <>
      <div className="portlet-body mx-3">
        <h4>Attendance Report</h4>
        <hr style={{ marginTop: "0px" }} />
        <div className="row">
          <div className="col-sm-12">
            <form
              className="form-horizontal"
              role="form"
              method="post"
              style={{ marginTop: "-20px" }}
            >
              <div className="row px-3">
                <div className="col-md-12">
                  <div className="row ">
                    <div className="col-md-2">
                      <div className="form-group">
                        <label
                          htmlFor="s2id_autogen2"
                          className="control-label"
                          style={{ marginLeft: "20px" }}
                        >
                          Class
                        </label>
                        <select
                          value={selectedOption2}
                          onChange={handleOption2Change}
                          style={{ marginLeft: "-10px" }}
                          name="classesID"
                          id="classesID"
                          className="form-control select2 select2-offscreen"
                          tabIndex="-1"
                        >
                          <option value="0" defaultValue="selected">
                            Select Class
                          </option>
                          <option value="1">I</option>
                          <option value="5">II</option>
                          {/* Add more options as needed */}
                        </select>{" "}
                      </div>
                    </div>
                    <div className="col-md-2">
                      <div className="form-group">
                        <label
                          style={{ marginLeft: "10px" }}
                          className="control-label"
                        >
                          Section
                        </label>
                        <select
                          value={selectedOption3}
                          onChange={handleOption3Change}
                          style={{ marginLeft: "-10px" }}
                          name="sectionID"
                          id="sectionID"
                          className="form-control select2 select2-offscreen"
                          tabIndex="-1"
                        >
                          <option value="0" defaultValue="selected">
                            Select Section
                          </option>
                          <option value="2">A</option>
                          <option value="3">B</option>
                          {/* Add more options as needed */}
                        </select>{" "}
                      </div>
                    </div>
                    <div className="col-md-2">
                      <div className="form-group">
                        <label
                          style={{ marginLeft: "10px" }}
                          className="control-label"
                        >
                          Date
                        </label>
                        <input
                          type="date"
                          value={selectedOption4}
                          onChange={handleOption4Change}
                          style={{ marginLeft: "-10px" }}
                          name="sectionID"
                          id="sectionID"
                          className="form-control select2 select2-offscreen"
                          tabIndex="-1"
                        ></input>{" "}
                      </div>
                    </div>
                    <div className="col-md-2">
                      <div className="form-group">
                        <label
                          htmlFor="s2id_autogen4"
                          className="control-label"
                        ></label>
                        <input
                          className="mt-1 btn btn-success"
                          type="button"
                          value="Attendance"
                          aria-hidden="true"
                          onClick={fetchData}
                          style={{
                            marginLeft: "-10px",
                            position: "relative",
                            top: "24px",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
            <div>
              <table className="table display dataTable" id="advance-1">
                <thead>
                  <tr>
                    <th>sr. no</th>
                    <th>Photo</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Roll</th>
                    <th>
                      Attendance all{" "}
                      <input
                        type="checkbox"
                        onChange={(event) =>
                          handleCheckboxChange(event, 5)
                        }
                      />
                    </th>
                  </tr>
                </thead>
                <tbody>{listItems}</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Add;
