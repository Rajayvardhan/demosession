import { createContext } from 'react';

const SearchResultContext = createContext();

export default SearchResultContext;
