export const BaseURL = "https://demo.keendroid.in";
export const schoolyearID = "10";